package com.winstrata.efa.stepdefs;

import static org.testng.Assert.assertEquals;

import org.testng.Assert;

import com.winstrata.efa.container.World;
import com.winstrata.efa.pages.HomePage;
import com.winstrata.efa.pages.T2DeparturePage;
import com.winstrata.efa.utils.WebDriverUtil;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;

public class DepartureSteps {

	private World world;

	public DepartureSteps(World world) {
		this.world = world;
	}

	@Given("^create T2 Departure order$")
	public void t2Departure(DataTable table) {

		HomePage hm = new HomePage(WebDriverUtil.driver);
		T2DeparturePage t2DeparturePage = new T2DeparturePage(WebDriverUtil.driver);

		try {

			hm.selectT2Departure();
			t2DeparturePage.createT2Departure(table);

		} catch (Exception e) {
			e.printStackTrace();
			StackTraceElement[] stacktrace = e.getStackTrace();

			StringBuffer exceptionMsgBuf = new StringBuffer();
			for (StackTraceElement element : stacktrace) {

				final String exceptionMsg = "Exception thrown from " + element.getMethodName() + " in class "
						+ element.getClassName() + " [on line number " + element.getLineNumber() + " of file "
						+ element.getFileName() + "]";
				exceptionMsgBuf.append(exceptionMsg);

			}

			assertEquals(true, false, exceptionMsgBuf.toString());
		}
	}

}
