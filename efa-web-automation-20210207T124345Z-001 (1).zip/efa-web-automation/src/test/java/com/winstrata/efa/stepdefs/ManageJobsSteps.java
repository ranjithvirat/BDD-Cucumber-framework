package com.winstrata.efa.stepdefs;

import org.testng.Assert;

import com.winstrata.efa.container.World;
import com.winstrata.efa.pages.HomePage;
import com.winstrata.efa.pages.JobPage;
import com.winstrata.efa.pages.RouteDetailsPage;
import com.winstrata.efa.pages.WorkOrderDetailsPage;
import com.winstrata.efa.utils.WebDriverUtil;
import static org.testng.Assert.assertEquals;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;

public class ManageJobsSteps {

	private World world;

	public ManageJobsSteps(World world) {
		this.world = world;
	}

	@Given("^create T2 manage jobs$")
	public void t2ManageJobs(DataTable table) {

		HomePage hm = new HomePage(WebDriverUtil.driver);
		JobPage jobPage = new JobPage(WebDriverUtil.driver);
		try {
			// job creation
			hm.selectT2ManageJobs();
			jobPage.createT2Job(table);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			StackTraceElement[] stacktrace = e.getStackTrace();

			StringBuffer exceptionMsgBuf = new StringBuffer();
			for (StackTraceElement element : stacktrace) {

				final String exceptionMsg = "Exception thrown from " + element.getMethodName() + " in class "
						+ element.getClassName() + " [on line number " + element.getLineNumber() + " of file "
						+ element.getFileName() + "]";
				exceptionMsgBuf.append(exceptionMsg);

			}

			assertEquals(true, false, exceptionMsgBuf.toString());
		}
	}
}
