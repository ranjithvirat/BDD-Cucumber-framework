package com.winstrata.efa.stepdefs;

import static org.testng.Assert.assertEquals;

import org.testng.Assert;

import com.winstrata.efa.container.World;
import com.winstrata.efa.pages.HomePage;
import com.winstrata.efa.pages.RouteDetailsPage;
import com.winstrata.efa.pages.WorkOrderDetailsPage;
import com.winstrata.efa.utils.WebDriverUtil;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;

public class WorkOrderSteps {

	private World world;

	public WorkOrderSteps(World world) {
		this.world = world;
	}

	@Given("^create T2 work order$")
	public void t2WorkOrder(DataTable table) {

		HomePage hm = new HomePage(WebDriverUtil.driver);
		WorkOrderDetailsPage workOrderDetailsPage = new WorkOrderDetailsPage(WebDriverUtil.driver);
		RouteDetailsPage rdp = new RouteDetailsPage(WebDriverUtil.driver);

		try {
			hm.selectT2WorkOrder();
			workOrderDetailsPage.createWorkOrder(table);
			rdp.createRouteDetails(table);
		} catch (Exception e) {
			e.printStackTrace();
			StackTraceElement[] stacktrace = e.getStackTrace();

			StringBuffer exceptionMsgBuf = new StringBuffer();
			for (StackTraceElement element : stacktrace) {

				final String exceptionMsg = "Exception thrown from " + element.getMethodName() + " in class "
						+ element.getClassName() + " [on line number " + element.getLineNumber() + " of file "
						+ element.getFileName() + "]";
				exceptionMsgBuf.append(exceptionMsg);

			}

			assertEquals(true, false, exceptionMsgBuf.toString());
		}
	}

}
