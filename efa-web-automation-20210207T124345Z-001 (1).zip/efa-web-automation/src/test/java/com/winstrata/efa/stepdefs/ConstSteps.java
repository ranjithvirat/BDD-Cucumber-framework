package com.winstrata.efa.stepdefs;

import com.winstrata.efa.container.World;

import io.cucumber.java.en.Then;

public class ConstSteps {

	private World world;

	public ConstSteps(World world) {
		this.world = world;
	}

	@Then("display my user")
	public void navigateToPageForgotPassword() {
		System.out.print("GOT MY CONST" + world.homePageConstants.myuser);

	}
}
