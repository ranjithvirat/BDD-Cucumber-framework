package com.winstrata.efa.stepdefs;

import static org.testng.Assert.assertEquals;

import org.testng.Assert;

import com.winstrata.efa.container.World;
import com.winstrata.efa.pages.AdvancedSearchPage;
import com.winstrata.efa.pages.HomePage;
import com.winstrata.efa.pages.T2BillGenerationPage;
import com.winstrata.efa.utils.WebDriverUtil;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class BillGenerationSteps {

	private World world;
	public BillGenerationSteps(World world) {
		this.world = world;
	}
	
	 @Given("^create T2 Bill Generation$")
	    public void t2BillGeneration(DataTable table) {
	 
	    	HomePage hm = new HomePage(WebDriverUtil.driver);
	    	T2BillGenerationPage t2BillGenerationPage = new T2BillGenerationPage(WebDriverUtil.driver);
	    
	    	try {		
	    		hm.selectT2BillGeneration();
	    		t2BillGenerationPage.t2BillGeneration(table);
	    		
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				Assert.assertTrue(false, e.getMessage());
			}
	    }
	 
	 @Then("^view T2 Generated Bill$")
	    public void t2ViewBillGeneration() {

	    	HomePage hm = new HomePage(WebDriverUtil.driver);
	    	AdvancedSearchPage advancedSearchPage = new AdvancedSearchPage(WebDriverUtil.driver);
	    
	    	try {		
	    		hm.selectT2BillGeneration();
	    		advancedSearchPage.advancedSearch();
	    		
			} catch (Exception e) {
				e.printStackTrace();
				StackTraceElement[] stacktrace = e.getStackTrace();

				StringBuffer exceptionMsgBuf = new StringBuffer();
				for (StackTraceElement element : stacktrace) {

					final String exceptionMsg = "Exception thrown from " + element.getMethodName() + " in class "
							+ element.getClassName() + " [on line number " + element.getLineNumber() + " of file "
							+ element.getFileName() + "]";
					exceptionMsgBuf.append(exceptionMsg);

				}

				assertEquals(true, false, exceptionMsgBuf.toString());
			}
	    }
}
