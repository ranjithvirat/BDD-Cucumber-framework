package com.winstrata.efa.stepdefs;

import static org.testng.Assert.assertEquals;

import org.testng.Assert;

import com.winstrata.efa.container.World;
import com.winstrata.efa.pages.CreditReceiptPage;
import com.winstrata.efa.pages.HomePage;
import com.winstrata.efa.pages.LoginPage;
import com.winstrata.efa.utils.WebDriverUtil;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;

public class CreditReceiptSteps {

	private World world;
	public CreditReceiptSteps(World world) {
		this.world = world;
	}
	
	 @Given("^create T2 CreditReceipt$")
	    public void t2CreditReceipt(DataTable table) {
	    	
	    	HomePage hm = new HomePage(WebDriverUtil.driver);
	    	LoginPage loginPage = new LoginPage(WebDriverUtil.driver);
	    	CreditReceiptPage creditReceiptPage = new CreditReceiptPage(WebDriverUtil.driver);
	    	try {		
	    		hm.selectCreditReceipt();
	    		loginPage.loginToCreditReceipt();
	    		creditReceiptPage.createCreditReceipt(table);
			} catch (Exception e) {
				e.printStackTrace();
				StackTraceElement[] stacktrace = e.getStackTrace();

				StringBuffer exceptionMsgBuf = new StringBuffer();
				for (StackTraceElement element : stacktrace) {

					final String exceptionMsg = "Exception thrown from " + element.getMethodName() + " in class "
							+ element.getClassName() + " [on line number " + element.getLineNumber() + " of file "
							+ element.getFileName() + "]";
					exceptionMsgBuf.append(exceptionMsg);

				}

				assertEquals(true, false, exceptionMsgBuf.toString());
			}
	    }
}
