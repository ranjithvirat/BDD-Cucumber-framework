package com.winstrata.efa.stepdefs;

import static org.testng.Assert.assertEquals;

import org.testng.Assert;

import com.winstrata.efa.container.World;
import com.winstrata.efa.pages.HomePage;
import com.winstrata.efa.pages.T2ArrivalPage;
import com.winstrata.efa.utils.WebDriverUtil;

import io.cucumber.java.en.Given;

public class ArrivalSteps {

	private World world;

	public ArrivalSteps(World world) {
		this.world = world;
	}

	@Given("^create T2 Arrival$")
	public void t2Arrival() {

		HomePage hm = new HomePage(WebDriverUtil.driver);
		T2ArrivalPage t2ArrivalPage = new T2ArrivalPage(WebDriverUtil.driver);

		try {
			hm.selectT2Arrival();
			t2ArrivalPage.fillT2ArrivalDetails();
		} catch (Exception e) {
			e.printStackTrace();
			StackTraceElement[] stacktrace = e.getStackTrace();

			StringBuffer exceptionMsgBuf = new StringBuffer();
			for (StackTraceElement element : stacktrace) {

				final String exceptionMsg = "Exception thrown from " + element.getMethodName() + " in class "
						+ element.getClassName() + " [on line number " + element.getLineNumber() + " of file "
						+ element.getFileName() + "]";
				exceptionMsgBuf.append(exceptionMsg);

			}

			assertEquals(true, false, exceptionMsgBuf.toString());
		}
	}
}
