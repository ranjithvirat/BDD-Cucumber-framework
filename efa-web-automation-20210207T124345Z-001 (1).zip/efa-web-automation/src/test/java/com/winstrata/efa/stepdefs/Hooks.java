package com.winstrata.efa.stepdefs;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriverException;

import com.winstrata.efa.utils.WebDriverUtil;

import io.cucumber.core.api.Scenario;
import io.cucumber.java.AfterStep;
import io.cucumber.java.BeforeStep;

public class Hooks extends WebDriverUtil {

	@BeforeStep
	public void beforeScenario() {
		System.out.println("*************************************");
		System.out.println("This will run before the Scenario");
	}

	@AfterStep
	public void embedScreenshot(Scenario scenario) {

		try {
			byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
			scenario.embed(screenshot, "image/png");
		} catch (WebDriverException wde) {
			System.err.println(wde.getMessage());
		} catch (ClassCastException cce) {
			cce.printStackTrace();
		}

	}
	
}
