package com.winstrata.efa.pages;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.Alert;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.winstrata.efa.pageobjects.JobPageObject;
import com.winstrata.efa.utils.Env;
import com.winstrata.efa.utils.SeleniumUtils;

import io.cucumber.datatable.DataTable;

public class JobPage extends JobPageObject {
 WebDriver driver;
	public JobPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
		this.driver = driver;
	}
	
	public void createT2Job(DataTable table) throws Exception {
		Thread.sleep(2000);
		 List<Map<String,String>> rows = table.asMaps(String.class, String.class);
		waitForElementClickable(btnAddNewJob).click();
		Thread.sleep(1000);
		waitForElementClickable(txtJobNo).sendKeys(Env.get("jobno"));
		Thread.sleep(1000);
		waitForElementClickable(txtJobNo).sendKeys(Keys.TAB);
		
		
     if (!SeleniumUtils.isAlertPresent(driver)) {
		waitForElementClickable(txtJobDesc).sendKeys(Env.get("jobno") + " description");
		Thread.sleep(1000);
		waitForElementClickable(txtCustomer).sendKeys(Env.get("customer"));
		waitForElementClickable(txtCustomer).sendKeys(Keys.TAB);;
		Thread.sleep(1000);
		
		waitForElementClickable(ddlWorkOrder).sendKeys(rows.get(0).get("WorkOrder"));
		final Select select = new Select(ddlWorkOrder);
		   int i = select.getOptions().size() - 1;
		   System.out.println("Size " + i);
	       try {
	        for (WebElement we: select.getOptions()) {
	        
	    		if (select.getOptions().get(i).getText().contains("JOB")) {
	        			System.out.println(select.getOptions().get(i).getText() + "ind " + i);
	        			Thread.sleep(100);
	        			select.selectByIndex(i);
	        	break;
	        		}
	        	i--;
	        }
	       } catch(org.openqa.selenium.StaleElementReferenceException ex) {
	    	   
	       }
		
		Thread.sleep(2000);
//		waitForElementClickable(ddlWorkOrder).sendKeys(Keys.ARROW_DOWN);
//		waitForElementClickable(ddlWorkOrder).sendKeys(Keys.ENTER);
//		waitForElementClickable(ddlWorkOrder).sendKeys(Keys.TAB);
	    Thread.sleep(3000);
		
		final Select select1 = new Select(ddlLoading);
		select1.selectByIndex(1);;
		Thread.sleep(3000);
		final Select select2 = new Select(ddlUnLoading);
	   
		select2.selectByIndex(1);
		Thread.sleep(3000);
		final Select select3 = new Select(ddlProduct);
	  
		select3.selectByIndex(1);
		Thread.sleep(3000);
		waitForElementClickable(txtQuantity).sendKeys(rows.get(0).get("Quantity"));
	
		Thread.sleep(300);
		waitForElementClickable(txtComments).sendKeys(rows.get(0).get("Comment"));
		Thread.sleep(500);
	
		waitForElementClickable(btnCreate).click();
		Thread.sleep(3000);
		  // Switching to Alert        
        Alert alert = driver.switchTo().alert();		
        		
        // Capturing alert message.    
        String alertMessage= driver.switchTo().alert().getText();		
        		
        // Displaying alert message		
        System.out.println(alertMessage);	
        Thread.sleep(5000);
        		
        // Accepting alert		
        alert.accept();	
        Thread.sleep(5000);
    }
		
	}

}
