package com.winstrata.efa.pages;

import java.util.Calendar;
import java.util.Date;
import java.time.format.DateTimeFormatter;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;    

import org.openqa.selenium.WebDriver;

import com.winstrata.efa.pageobjects.T2ArrivalPageObject;
import com.winstrata.efa.utils.Env;

public class T2ArrivalPage extends T2ArrivalPageObject {

	public T2ArrivalPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	public void fillT2ArrivalDetails() throws InterruptedException {
		Thread.sleep(3000);
		waitForElementClickable(txtTripSheetNumber).sendKeys(Env.get("tsno"));
		Thread.sleep(1000);
		waitForElementClickable(btnArrival).click();
		Thread.sleep(1000);
	
		 DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");  
		   LocalDateTime now = LocalDateTime.now();  
		   System.out.println(dtf.format(now));  
		setJSValue("ctl00_Main_ArrivalWUC1_dwArrdate_txtDate", dtf.format(now));
		Thread.sleep(1000);
		waitForElementClickable(btnContinue).click();
		Thread.sleep(1000);
		waitForElementClickable(btnSubmit).click();
		Thread.sleep(3000);
		waitForElementClickable(btnSaveArrival).click();
		Thread.sleep(5000);
	}
}
