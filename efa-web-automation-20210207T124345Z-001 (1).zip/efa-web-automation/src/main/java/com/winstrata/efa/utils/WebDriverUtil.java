package com.winstrata.efa.utils;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.winstrata.efa.pages.LoginPage;

import io.github.bonigarcia.wdm.WebDriverManager;

public class WebDriverUtil {
	public static WebDriver driver;

	@BeforeSuite
	public void setUp() {
		try {
			Env.loadProperties();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("MY BROWSER *********" + System.getProperty("browser"));
		if (System.getProperty("browser").contains("chrome")) {
			WebDriverManager.chromedriver().setup();

			if (driver == null) {
				driver = new ChromeDriver();
				   DesiredCapabilities capabilities = DesiredCapabilities.chrome();
			        capabilities.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.ACCEPT);
			        capabilities.setCapability(CapabilityType.UNHANDLED_PROMPT_BEHAVIOUR, "DISMISS");
			}
		} else if (System.getProperty("browser").contains("firefox")) {
			WebDriverManager.firefoxdriver().setup();

			if (driver == null) {
				driver = new FirefoxDriver();
			}
		}
		driver.manage().window().maximize();
		driver.navigate().to(Env.get("loginURL"));
		waitForPageLoaded();
		LoginPage homePage = new LoginPage(driver);
		homePage.loginToEfa();
	}

	// driver.manage().timeouts().pageLoadTimeout(15, TimeUnit.SECONDS);

	@AfterSuite
	public void tearDown() {
		if (driver != null) {
			driver.manage().deleteAllCookies();
			driver.close();
			if (driver != null)
			driver.quit();
		}
	}

	public void waitForPageLoaded() {
		ExpectedCondition<Boolean> expectation = new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver driver) {
				return ((JavascriptExecutor) driver).executeScript("return document.readyState").toString()
						.equals("complete");
			}
		};
		try {
			driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			WebDriverWait wait = new WebDriverWait(driver, 15);
			wait.until(expectation);
		} catch (Throwable error) {
			Assert.fail("Timeout waiting for Page Load Request to complete.");
		}
	}

}
