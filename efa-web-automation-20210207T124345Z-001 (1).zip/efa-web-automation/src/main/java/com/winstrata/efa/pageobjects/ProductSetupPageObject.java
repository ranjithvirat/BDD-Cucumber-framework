package com.winstrata.efa.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ProductSetupPageObject extends PageObject{

	public ProductSetupPageObject(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	

	@FindBy(id = "ctl00_Main_ManageProduct1_CustomerSelector1_ddl_Cust")
	public WebElement customerSelect;
	
	@FindBy(id = "ctl00_Main_ManageProduct1_ddlType")
	public WebElement productType;
	
	@FindBy(id = "ctl00_Main_ManageProduct1_ddlProductName")
	public WebElement productName;
	
	@FindBy(xpath = "//input[@name='ctl00$Main$ManageProduct1$txtProductCode'][contains(@id,'txtProductCode')]")
	public WebElement productCodeEdt;
	
	
	@FindBy(xpath = "//input[@name='ctl00$Main$ManageProduct1$btnAdd']")
	public WebElement addProductSetupBtn;

	@FindBy(xpath = "//textarea[@id='ctl00_Main_ManageProduct1_txtDescription']")
	public WebElement txtDescription;
	
	@FindBy(xpath = "//input[@value='Add Name']")
	public WebElement btnAddName;
	
	@FindBy(xpath = "//input[@id='ctl00_Main_ManageProduct1_AddToLkp1_LC_nameTxt']")
	public WebElement txtAddProductName;
	
	@FindBy(xpath = "//input[@type='submit'][contains(@id,'submitBtn')]")
	public WebElement btnAdd;
	
	@FindBy(xpath = "//input[@value='Back']")
	public WebElement btnBack;
	
	@FindBy(xpath = "//span[contains(.,'Product Name added successfully')]")
	public WebElement msgProductAdded;
	
	@FindBy(xpath = "//span[contains(.,'Product Name already exists')]")
	public WebElement productMsgLbl;
	
}
