package com.winstrata.efa.pages;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.winstrata.efa.pageobjects.RouteDetailsPageObject;
import com.winstrata.efa.utils.Env;

import io.cucumber.datatable.DataTable;

public class RouteDetailsPage extends RouteDetailsPageObject {

	public RouteDetailsPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	public void createRouteDetails(DataTable table) throws Exception {
		
		List<Map<String,String>> rows = table.asMaps(String.class, String.class);
		routeDetailsTab.click();
		Thread.sleep(3000);
		ddlImpExp.sendKeys(rows.get(0).get("ImpOrExp"));
		Thread.sleep(2000);
		ddlRouteProducts.sendKeys(Env.get("workorderproduct"));
		Thread.sleep(2000);
		txtWeightSlabStart.sendKeys(rows.get(0).get("WeightSlabStart"));
		Thread.sleep(2000);
		txtWeightSlabEnd.sendKeys(rows.get(0).get("WeightSlabEnd"));
		Thread.sleep(2000);
		txtRate.sendKeys(rows.get(0).get("Rate"));
		txtBattaRate.sendKeys(rows.get(0).get("BattaRate"));
		btnAddRouteRate.click();
		Thread.sleep(2000);
		  JavascriptExecutor js = (JavascriptExecutor) driver;
		  js.executeScript("arguments[0].scrollIntoView();", btnSubmit);
		btnSubmit.click();
		Thread.sleep(3000);
		Assert.assertTrue(msgAddedWorkOrder.isDisplayed(), "Unable to  add new work order");
		Thread.sleep(2000);
	}
}
