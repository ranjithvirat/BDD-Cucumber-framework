package com.winstrata.efa.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class RouteDetailsPageObject extends PageObject {

	public RouteDetailsPageObject(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	@FindBy(xpath = "//a[contains(.,'ROUTE DETAILS')]")
	public WebElement routeDetailsTab;
	
	@FindBy(id = "ctl00_Main_wizAddWorkOrder_RD1_RouteSetupFrm1_ddlImpExp")
	public WebElement ddlImpExp;
	
	@FindBy(id = "ctl00_Main_wizAddWorkOrder_RD1_RouteSetupFrm1_RouteSelector1_ddl_Item")
	public WebElement ddlRoutFrom;
	
	@FindBy(id = "ctl00_Main_wizAddWorkOrder_RD1_RouteSetupFrm1_RouteSelector2_ddl_Item")
	public WebElement ddlRouteTo;
	
	@FindBy(id = "ctl00_Main_wizAddWorkOrder_RD1_RouteSetupFrm1_ddlRouteProducts")
	public WebElement ddlRouteProducts;
	
	@FindBy(id = "ctl00_Main_wizAddWorkOrder_RD1_RouteSetupFrm1_txtWeightSlabStart")
	public WebElement txtWeightSlabStart;
	
	@FindBy(xpath = "//input[contains(@name,'txtWeightSlabEnd')]")
	public WebElement txtWeightSlabEnd;
	
	@FindBy(id = "ctl00_Main_wizAddWorkOrder_RD1_RouteSetupFrm1_txtRate")
	public WebElement txtRate;
	
	@FindBy(id = "ctl00_Main_wizAddWorkOrder_RD1_RouteSetupFrm1_txtBattaRate")
	public WebElement txtBattaRate;
	
	@FindBy(id = "ctl00_Main_wizAddWorkOrder_RD1_RouteSetupFrm1_AddRouteRateBtn")
	public WebElement btnAddRouteRate;
	
	@FindBy(xpath = "//input[@type='submit'][contains(@id,'btnSubmit')]")
	public WebElement btnSubmit;
	
	@FindBy(xpath = "//span[contains(.,'Successfully added Work Order Details')]")
	public WebElement msgAddedWorkOrder;
	
}
