package com.winstrata.efa.pages;

import java.io.IOException;
import java.util.Base64;

import org.openqa.selenium.WebDriver;

import com.winstrata.efa.container.World;
import com.winstrata.efa.pageobjects.LoginPageObject;
import com.winstrata.efa.utils.Env;

public class LoginPage extends LoginPageObject {

	
	public LoginPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	public void loginToEfa() {
		waitForVisibilityOf(loginName).sendKeys(Env.get("username").toString());
        byte[] decodedBytes = Base64.getDecoder().decode(Env.get("password"));
		String decodedString = new String(decodedBytes);
		

		password.sendKeys(decodedString);
		loginBtn.click();
	}
	
	public void loginToCreditReceipt() throws InterruptedException {
	
		waitForVisibilityOf(userName).sendKeys(Env.get("username").toString());
		Thread.sleep(1000);
        byte[] decodedBytes = Base64.getDecoder().decode(Env.get("password"));
		String decodedString = new String(decodedBytes);
		pwd.sendKeys(decodedString);
		btnLogin.click();
		Thread.sleep(1000);
	}

}
