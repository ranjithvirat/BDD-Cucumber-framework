package com.winstrata.efa.pages;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.winstrata.efa.pageobjects.T2BillGenerationPageObject;
import com.winstrata.efa.utils.Env;
import com.winstrata.efa.utils.SeleniumUtils;

import io.cucumber.datatable.DataTable;

public class T2BillGenerationPage extends T2BillGenerationPageObject {

	public T2BillGenerationPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	public void t2BillGeneration(DataTable table) throws Exception {
		
		List<Map<String,String>> rows = table.asMaps(String.class, String.class);
		waitForElementClickable(btnGenerateNewBill).click();
		Thread.sleep(1000);
		waitForElementClickable(txtCustomer).sendKeys(Env.get("customer"));
		waitForElementClickable(txtCustomer).sendKeys(Keys.TAB);;
		Thread.sleep(1000);

		final Select select = new Select(ddlWONo);
		
		   int i = select.getOptions().size() - 1;
		   System.out.println("Size " + i);
	       try {
	        for (WebElement we: select.getOptions()) {
	        
	    		if (select.getOptions().get(i).getText().contains(rows.get(0).get("WorkOrder"))) {
	        			System.out.println(select.getOptions().get(i).getText() + "ind " + i);
	        			Thread.sleep(100);
	        			select.selectByIndex(i);
	        	break;
	        		}
	    		//System.out.println(we.getText() + "ind " + i);
	        	i--;
	        }
	       } catch(org.openqa.selenium.StaleElementReferenceException ex) {
	    	   
	       }
		Thread.sleep(5000);
		
		
		waitForElementClickable(txtJob).sendKeys(Env.get("jobno"));
		waitForElementClickable(txtJob).sendKeys(Keys.TAB);;
		Thread.sleep(3000);
		
		
		waitForElementClickable(ddlTemplate).sendKeys(rows.get(0).get("Template"));
		waitForElementClickable(ddlTemplate).sendKeys(Keys.TAB);;
		Thread.sleep(2000);
		waitForElementClickable(btnListTrips).click();
		Thread.sleep(2000);
		
		waitForElementClickable(rbtnTripSheet).click();
		
		Thread.sleep(2000);
		
       waitForElementClickable(btnGenerate).click();
		
		Thread.sleep(5000);
		
waitForElementClickable(btnConfirmDispatch).click();
		
		Thread.sleep(5000);
	}
}
