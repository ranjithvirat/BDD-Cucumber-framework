package com.winstrata.efa.utils;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class Env {

	  public static Properties env; 
	  
	  public static void loadProperties() throws IOException {
	    	FileReader reader;
			reader = new FileReader("src/main/resources/env.properties");        
			env = new Properties(); 
	    	env.load(reader);
		reader.close();
	    }
	  
	  public static String get(String key) {
	 	return   env.get(key).toString();  
	  }
}
