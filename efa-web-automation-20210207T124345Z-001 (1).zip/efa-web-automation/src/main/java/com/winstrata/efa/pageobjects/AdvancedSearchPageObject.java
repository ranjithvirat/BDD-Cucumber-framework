package com.winstrata.efa.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AdvancedSearchPageObject extends PageObject {


	public AdvancedSearchPageObject(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	
	@FindBy(xpath = "//input[@value='Advanced Search']")
	public WebElement btnAdvancedSearch;
	
	@FindBy(xpath = "//input[@id='ctl00_Main_txtCustomerSear']")
	public WebElement txtCustomerSearch;
	
	@FindBy(xpath = "//input[@id='ctl00_Main_txtJobSear']")
	public WebElement txtJobSearch;
	
	@FindBy(xpath = "//input[@value='Search']")
	public WebElement btnSearch;
	
	@FindBy(xpath = "//input[@id='ctl00_Main_cgvSearchBill_ctl02_imgbtn_view']")
	public WebElement imgBtnView;
	
}
