package com.winstrata.efa.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class JobPageObject extends PageObject {

	public JobPageObject(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	@FindBy(xpath = "//input[@type='submit'][contains(@id,'btnAddNewJob')]")
	public WebElement btnAddNewJob;
	
	@FindBy(id = "ctl00_Main_txtJobNo")
	public WebElement txtJobNo;
	
	@FindBy(id = "ctl00_Main_txtJobDesc")
	public WebElement txtJobDesc;
	
	@FindBy(id = "ctl00_Main_ListProductsForRoutes1_txtCustomer")
	public WebElement txtCustomer;
	
	@FindBy(id = "ctl00_Main_ListProductsForRoutes1_ddlWorkOrder")
	public WebElement ddlWorkOrder;
	
	@FindBy(id = "ctl00_Main_ListProductsForRoutes1_ddlLoading")
	public WebElement ddlLoading;
	
	@FindBy(id = "ctl00_Main_ListProductsForRoutes1_ddlUnLoading")
	public WebElement ddlUnLoading;
	
	@FindBy(xpath = "//select[@id='ctl00_Main_ListProductsForRoutes1_ddlProduct']")
	public WebElement ddlProduct;
	
	@FindBy(xpath = "//input[@id='ctl00_Main_txtQuantity']")
	public WebElement txtQuantity;
	
	@FindBy(xpath = "//textarea[@id='ctl00_Main_TxtComments']")
	public WebElement txtComments;
	
	@FindBy(xpath = "//input[@type='button'][contains(@id,'btnCreate')]")
	public WebElement btnCreate;
	
}
