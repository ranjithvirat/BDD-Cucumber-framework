package com.winstrata.efa.utils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;

public class CucumberReport {
	public void report() {
		File reportOutputDirectory = new File("target/site");
		List<String> jsonFiles = new ArrayList<>();
		jsonFiles.add("target/cucumber/cucumber.json");

		String buildNumber = "100";
		String projectName = "Winstrata eFA";
		Configuration configuration = new Configuration(reportOutputDirectory, projectName);
		configuration.setBuildNumber(buildNumber);
		ReportBuilder reportBuilder = new ReportBuilder(jsonFiles, configuration);
		reportBuilder.generateReports();
	}
}
