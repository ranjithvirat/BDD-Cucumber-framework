package com.winstrata.efa.container;

import com.winstrata.efa.constants.HomePageConstants;


public class World {
	public HomePageConstants homePageConstants;
	public World() {
		this.homePageConstants = new HomePageConstants();
		
	}

}
