package com.winstrata.efa.constants;

public class HomePageConstants {
public String myuser;
}
