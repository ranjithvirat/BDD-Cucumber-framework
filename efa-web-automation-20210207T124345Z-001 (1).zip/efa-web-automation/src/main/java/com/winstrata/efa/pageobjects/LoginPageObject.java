package com.winstrata.efa.pageobjects;

import org.openqa.selenium.support.FindBy;

import org.openqa.selenium.*;

public class LoginPageObject extends PageObject {

	


	public LoginPageObject(WebDriver driver) {
		super(driver);
		System.out.print("KRISHNA TEST TEST TEST");

	}

	@FindBy(id = "ctl00_Main_Login1_UserName")
	public WebElement loginName;

	@FindBy(id = "ctl00_Main_Login1_Password")
	public WebElement password;
	
	@FindBy(id = "ctl00_Main_Login1_LoginButton")
	public WebElement loginBtn;
	
	//credit receipt
	@FindBy(xpath = "//input[@id='ctl00_Main_LoginBox_UserName']")
	public WebElement userName;
	
	@FindBy(xpath = "//input[@id='ctl00_Main_LoginBox_Password']")
	public WebElement pwd;
	
	@FindBy(xpath = "//input[@id='ctl00_Main_LoginBox_LoginButton']")
	public WebElement btnLogin;
	
//    public ResearchPage submit(){
//        searchInput.click();
//        return new ResearchPage(driver);
//    }
//
//

}