package com.winstrata.efa.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PageObject {

	protected WebDriver driver;

	public PageObject(WebDriver driver) {
		this.driver = driver;

		PageFactory.initElements(driver, this);
	}

	public void waitForVisibilityOf(By locator) {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
	}

	public WebElement waitForVisibilityOf(WebElement we) {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		return wait.until(ExpectedConditions.elementToBeClickable(we));
	}
	
	public WebElement waitForElementClickable(WebElement we) {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.ignoring(StaleElementReferenceException.class);
		
	
	  wait.until(
		        ExpectedConditions.refreshed(ExpectedConditions.elementToBeClickable(we)));
	
	  return 	wait.until(ExpectedConditions.elementToBeClickable(we));
		
	}
	
	public void waitForElementAndSendValues(WebElement we, int milliSceonds,  CharSequence... keysToSend) throws Exception {
	    this.waitForElementClickable( we ).sendKeys(keysToSend);
		Thread.sleep(milliSceonds);
	}
	
	public void waitForElementEnabledAndClick(WebElement we, int milliSceonds) throws Exception {
	    this.waitForElementClickable( we ).click();
		Thread.sleep(milliSceonds);
	}
	
	public void setJSValue(String id, String value) {
		((JavascriptExecutor)driver).executeScript(
				"document.getElementById('" +id + "').setAttribute('value','" + value + "')");
	}
}