package com.winstrata.efa.pages;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

import com.winstrata.efa.pageobjects.ProductSetupPageObject;
import com.winstrata.efa.utils.Env;
import com.winstrata.efa.utils.SeleniumUtils;

import io.cucumber.datatable.DataTable;

public class ProductSetupPage extends ProductSetupPageObject {

	public ProductSetupPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub

	}

	public void productSetup(DataTable table) throws Exception {

		List<Map<String, String>> rows = table.asMaps(String.class, String.class);
		Thread.sleep(1000);
		waitForElementClickable(customerSelect).sendKeys(Env.get("customer"));
		Thread.sleep(1000);
		waitForElementClickable(productType).sendKeys(rows.get(0).get("ProductType"));
		Thread.sleep(3000);
		waitForElementClickable(btnAddName).click();
		Thread.sleep(2000);
     	waitForElementClickable(txtAddProductName).sendKeys(Env.get("workorderproduct"));
		Thread.sleep(1000);
		waitForElementClickable(btnAdd).click();
		Thread.sleep(2000);
		if (!productMsgLbl.isDisplayed()) {
		waitForElementClickable(btnBack).click();
		Thread.sleep(2000);
		waitForElementClickable(productName).sendKeys(Env.get("workorderproduct"));
		Thread.sleep(3000);
		productCodeEdt.sendKeys(Env.get("code"));
		Thread.sleep(1000);
		txtDescription.sendKeys("my product setup" + Env.get("code"));
		Thread.sleep(4000);
		addProductSetupBtn.click();
		} else {
			waitForElementClickable(btnBack).click();
		}
		Thread.sleep(3000);

	}
}
