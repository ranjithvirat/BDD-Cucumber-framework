package com.winstrata.efa.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class T2ArrivalPageObject extends PageObject {

	public T2ArrivalPageObject(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	
	@FindBy(xpath = "//input[@id='ctl00_Main_txtTripsheet']")
	public WebElement txtTripSheetNumber;
	
	
	
	@FindBy(id = "ctl00_Main_btnArrival")
	public WebElement btnArrival;
	
	@FindBy(xpath = "//input[contains(@value,'Continue')]")
	public WebElement btnContinue;
	
	@FindBy(xpath = "//input[@value='Submit']")
	public WebElement btnSubmit;
	
	@FindBy(xpath = "//input[@value='Save Arrival']")
	public WebElement btnSaveArrival;
	

}
