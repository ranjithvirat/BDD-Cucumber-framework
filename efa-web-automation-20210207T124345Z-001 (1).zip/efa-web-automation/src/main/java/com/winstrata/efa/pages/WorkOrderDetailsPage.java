package com.winstrata.efa.pages;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.winstrata.efa.pageobjects.WorkOrderDetailsPageObject;
import com.winstrata.efa.utils.Env;

import io.cucumber.datatable.DataTable;

public class WorkOrderDetailsPage extends WorkOrderDetailsPageObject {

	WebDriver driver;
	public WorkOrderDetailsPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
		// TODO Auto-generated constructor stub
	}

	public void createWorkOrder(DataTable table) throws Exception {
		
		 List<Map<String,String>> rows = table.asMaps(String.class, String.class);
		waitForElementClickable(btnAddNew).click();
		waitForElementClickable(selectCustomer).sendKeys(Env.get("customer"));
		Thread.sleep(1000);
		setJSValue("ctl00_Main_wizAddWorkOrder_MW1_DateWidget1_txtDate", rows.get(0).get("EffectiveDate"));
		ddlProductType.sendKeys(rows.get(0).get("ProductType"));
		Thread.sleep(1000);
		selectProductChklist(Env.get("workorderproduct")).click();
		ddlBilledFor.sendKeys(rows.get(0).get("BilledFor"));
		Thread.sleep(1000);
		
		
	}
	
}
