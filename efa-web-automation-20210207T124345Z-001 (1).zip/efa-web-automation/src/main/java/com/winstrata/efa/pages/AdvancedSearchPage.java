package com.winstrata.efa.pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import com.winstrata.efa.container.World;
import com.winstrata.efa.pageobjects.AdvancedSearchPageObject;
import com.winstrata.efa.utils.Env;

public class AdvancedSearchPage extends AdvancedSearchPageObject {

	World world;
	public AdvancedSearchPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	public void advancedSearch() throws InterruptedException {
		Thread.sleep(1000);
		waitForElementClickable(btnAdvancedSearch).click();
		
		waitForElementClickable(txtCustomerSearch).sendKeys(Env.get("customer"));
		Thread.sleep(2000);
		waitForElementClickable(txtCustomerSearch).sendKeys(Keys.ARROW_DOWN);
		waitForElementClickable(txtCustomerSearch).sendKeys(Keys.ENTER);
		waitForElementClickable(txtCustomerSearch).sendKeys(Keys.TAB);
		Thread.sleep(1000);
		waitForElementClickable(txtJobSearch).sendKeys(Env.get("jobno"));
		Thread.sleep(2000);
		waitForElementClickable(txtJobSearch).sendKeys(Keys.ARROW_DOWN);
		waitForElementClickable(txtJobSearch).sendKeys(Keys.ENTER);
		waitForElementClickable(txtJobSearch).sendKeys(Keys.TAB);
		Thread.sleep(1000);
		waitForElementClickable(btnSearch).click();
		Thread.sleep(2000);
		waitForElementClickable(imgBtnView).click();
		Thread.sleep(5000);
	}
}
