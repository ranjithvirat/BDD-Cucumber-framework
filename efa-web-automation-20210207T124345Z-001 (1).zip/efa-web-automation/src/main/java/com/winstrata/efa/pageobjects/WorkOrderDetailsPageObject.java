package com.winstrata.efa.pageobjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class WorkOrderDetailsPageObject extends PageObject {

	WebDriver driver;
	public WorkOrderDetailsPageObject(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
		this.driver = driver;
	}

	@FindBy(id = "ctl00_Main_btnAddNew")
	public WebElement btnAddNew;
	
	@FindBy(id = "ctl00_Main_CustomerSelector1_ddl_Cust")
	public WebElement selectCustomer;
	
	@FindBy(id = "ctl00_Main_wizAddWorkOrder_MW1_DateWidget1_txtDate")
	public WebElement txtEffectiveDate;
	
	@FindBy(id= "ctl00_Main_wizAddWorkOrder_MW1_DateWidget1_imgCalendar")
	public WebElement effectiveDateCalendar;
	
	@FindBy(id = "ctl00_Main_wizAddWorkOrder_MW1_DateWidget1_imgCalendar")
	public WebElement expiryDateCalendar;
	
	@FindBy(id = "ctl00_Main_wizAddWorkOrder_MW1_ddlProductType")
	public WebElement ddlProductType;
	
	@FindBy(id = "ctl00_Main_wizAddWorkOrder_MW1_ddlBillledFor")
	public WebElement ddlBilledFor;
	
	@FindAll(@FindBy(how = How.XPATH, using = "(//input[@type='checkbox'])"))
	public List<WebElement> productChklist2;
	

	
	
	public WebElement selectProductChklist(String productName) {
		return driver.findElement(By.xpath("//label[contains(.,'" + productName + "')]"));
	}
}
