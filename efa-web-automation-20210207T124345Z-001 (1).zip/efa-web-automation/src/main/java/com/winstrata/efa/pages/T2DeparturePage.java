package com.winstrata.efa.pages;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import com.winstrata.efa.pageobjects.T2DeparturePageObject;
import com.winstrata.efa.utils.Env;
import com.winstrata.efa.utils.SeleniumUtils;

import io.cucumber.datatable.DataTable;

public class T2DeparturePage extends T2DeparturePageObject {

	WebDriver driver;
	public T2DeparturePage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
		this.driver = driver;
	}
	
	public void createT2Departure(DataTable table) throws Exception  {
		
		List<Map<String,String>> rows = table.asMaps(String.class, String.class);
		Thread.sleep(2000);
		ddlImpExp.sendKeys(rows.get(0).get("ImpOrExp"));
		Thread.sleep(2000);
		waitForElementClickable(txtVehicle).sendKeys(Env.get("vehicle1"));
		Thread.sleep(2000);
		waitForElementClickable(txtVehicle).sendKeys(Keys.ARROW_DOWN);
		waitForElementClickable(txtVehicle).sendKeys(Keys.ENTER);
		waitForElementClickable(txtVehicle).sendKeys(Keys.TAB);
	    Thread.sleep(3000);
	    if (txtVehicleWt.isDisplayed()) {
	    waitForElementClickable(txtVehicleWt).sendKeys(rows.get(0).get("VehicleWeight"));
	    btnYes.click();
	   }
	   
	//    Thread.sleep(2000);
	//	waitForElementClickable(txtPriDriver).sendKeys(Env.get("driver1"));
		Thread.sleep(3000);
//		waitForElementClickable(txtPriDriver).sendKeys(Keys.ARROW_DOWN);
//		waitForElementClickable(txtPriDriver).sendKeys(Keys.ENTER);
//		waitForElementClickable(txtPriDriver).sendKeys(Keys.TAB);
		 
		 waitForElementClickable(btnContinue).click();
		  Thread.sleep(5000);
		  
		  //Departure details Env.get("customer")
		  waitForElementClickable(txtTripsheetNo).sendKeys(Env.get("tsno"));
		  Thread.sleep(2000);
		  waitForElementClickable(txtCustomer).sendKeys(Env.get("customer"));
		  waitForElementClickable(txtCustomer).sendKeys(Keys.TAB);
		  Thread.sleep(2000);
		//  waitForElementClickable(rbtnJob).click();
		  
		  SeleniumUtils su = new SeleniumUtils();
		  int indx = su.getRbtnIndex(driver, jobTable, Env.get("jobno"));
		  selectRadioBtn(indx).click();
		  Thread.sleep(2000);
		  waitForElementClickable(ddlSize1).sendKeys(Env.get("productname"));
		  waitForElementClickable(ddlSize1).sendKeys(Keys.TAB);
		  Thread.sleep(2000);
		  waitForElementClickable(txtContNo1).sendKeys(Env.get("contno1"));
		  waitForElementClickable(btnNext).click();
		  Thread.sleep(2000);
		  JavascriptExecutor js = (JavascriptExecutor) driver;
		  js.executeScript("arguments[0].scrollIntoView();", btnSubmit);
		  Thread.sleep(2000);
		  waitForElementClickable(btnSubmit).click();
		  Thread.sleep(10000);
		  js.executeScript("arguments[0].scrollIntoView();", btnSave);
		  waitForElementClickable(btnSave).click();
		  Thread.sleep(10000);
		  
	}

}
