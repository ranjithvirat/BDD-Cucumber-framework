package com.winstrata.efa.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePageObject extends PageObject{

	public HomePageObject(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	@FindBy(xpath = "(//div[contains(@onmouseover,'PopOut_Down(this)')])[4]")
	public WebElement menuTripSheet;
	@FindBy(xpath = "(//a[contains(.,'Employee')])[1]")
	public WebElement employee;
	
	@FindBy(xpath = "(//a[contains(.,'Corporate')])[1]")
	public WebElement corporate;
	
	@FindBy(xpath = "(//a[contains(.,'Trip Sheet')])[1]")
	public WebElement tripsheet;
	
	@FindBy(xpath = "//a[contains(.,'Product Setup')]")
	public WebElement productSetup;
	
	@FindBy(xpath = "//a[contains(.,'T2 Work Order')]")
	public WebElement t2WorkOrder;
	
	@FindBy(xpath = "//a[contains(.,'T2 Manage Jobs')]")
	public WebElement t2ManageJobs;
	
	@FindBy(xpath = "//a[contains(.,'T2 Departure')]")
	public WebElement t2Departure;
	
	@FindBy(xpath = "//a[contains(.,'T2 Arrival')]")
	public WebElement t2Arrival;
	
	@FindBy(xpath = "(//a[contains(.,'Finance')])[1]")
	public WebElement finance;
	
	@FindBy(xpath = "//a[contains(.,'Credit Receipts')]")
	public WebElement creditReceipts;
	
	
	@FindBy(xpath = "//a[contains(.,'T2_BillGeneration')]")
	public WebElement t2BillGeneration;
}
