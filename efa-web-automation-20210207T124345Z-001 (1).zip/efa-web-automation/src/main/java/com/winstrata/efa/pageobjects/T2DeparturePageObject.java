package com.winstrata.efa.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;



public class T2DeparturePageObject extends PageObject {

	public T2DeparturePageObject(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	@FindBy(id = "ctl00_Main_DepartureEntry1_ddlImpExp")
	public WebElement ddlImpExp;
	
	
	@FindBy(id = "ctl00_Main_DepartureEntry1_txtVehicle")
	public WebElement txtVehicle;
	
	@FindBy(xpath = "//ul[@id='aceDeptVehicle_completionListElem']")
	public WebElement vehicleList;
	
	@FindBy(xpath = "//input[@id='ctl00_Main_DepartureEntry1_txtVehicleWt']")
	public WebElement txtVehicleWt;
	
	@FindBy(xpath = "//input[@id='ctl00_Main_DepartureEntry1_btnYes']")
	public WebElement btnYes;
	
	@FindBy(id = "ctl00_Main_DepartureEntry1_txtPriDriver")
	public WebElement txtPriDriver;
	
	@FindBy(xpath = "//input[@type='submit'][contains(@id,'btnNext')]")
	public WebElement btnContinue;
	//Second screen
	
	
	
	@FindBy(id = "ctl00_Main_DepartureWUC1_txtTripsheetNo")
	public WebElement txtTripsheetNo;
	
	@FindBy(id = "ctl00_Main_DepartureWUC1_txtCustomer")
	public WebElement txtCustomer;
	
	@FindBy(xpath = "//input[@value='rbtn']")
	public WebElement rbtnJob;
	
	@FindBy(id = "ctl00_Main_DepartureWUC1_ddlSize1")
	public WebElement ddlSize1;
	
	@FindBy(id = "ctl00_Main_DepartureWUC1_txtContNo1")
	public WebElement txtContNo1;
	
	@FindBy(id = "ctl00_Main_DepartureWUC1_btnNext")
	public WebElement btnNext;
	
	@FindBy(id = "ctl00_Main_btnSubmit")
	public WebElement btnSubmit;
	
	@FindBy(id = "ctl00_Main_btnSave")
	public WebElement btnSave;
	
	@FindBy(xpath = "/html/body/form/table/tbody/tr[4]/td/div[1]/table/tbody/tr/td/div/table/tbody/tr[2]/td[2]/div/table/tbody/tr[4]/td[1]/table/tbody/tr[2]/td/div/div/table/tbody/tr[5]/td/div/table/tbody")
	public WebElement jobTable;
	
	public WebElement selectRadioBtn(int indx) {
		return driver.findElement(By.xpath("(//input[@value='rbtn'])[" + indx + "]"));
	}
	
}
