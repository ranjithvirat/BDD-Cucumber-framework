package com.winstrata.efa.utils;

import io.cucumber.testng.CucumberFeatureWrapper;
import io.cucumber.testng.CucumberOptions;
import io.cucumber.testng.PickleEventWrapper;
import io.cucumber.testng.TestNGCucumberRunner;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

@CucumberOptions(features = "src/test/resources", glue = { "com.winstrata.efa.stepdefs" }, plugin = {
		"com.winstrata.efa.utils.CucumberEventListener", "pretty",
		"json:target/cucumber/cucumber.json" }, dryRun = false

)
public class TestNgCucumberScenarioRunner {
	private TestNGCucumberRunner testNGCucumberRunner;

	@BeforeClass(alwaysRun = true)
	public void setUpClass() {
		testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
	}

	@Test(groups = "cucumber", description = "Runs Cucumber Feature", dataProvider = "scenarios")
	public void feature(PickleEventWrapper pickelEventWrapper, CucumberFeatureWrapper cucumberFeature)
			throws Throwable {
		testNGCucumberRunner.runScenario(pickelEventWrapper.getPickleEvent());
	}

	@DataProvider
	public Object[][] scenarios() {
		return testNGCucumberRunner.provideScenarios();
	}

	@AfterClass(alwaysRun = true)
	public void tearDownClass() {
		testNGCucumberRunner.finish();
	}

	@AfterSuite()
	public void afterSuite() {
		CucumberReport cb = new CucumberReport();
		cb.report();
	}

}
