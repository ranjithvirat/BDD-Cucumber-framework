package com.winstrata.efa.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CreditReceiptPageObject extends PageObject {

	public CreditReceiptPageObject(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	@FindBy(xpath = "//input[@id='ctl00_Main_btnAddNew']")
	public WebElement btnAddNew;
	
	@FindBy(xpath = "//select[@id='ctl00_Main_AddPaymentReceipts1_ddlCustomer']")
	public WebElement ddlCustomer;
	
	@FindBy(xpath = "//select[contains(@id,'ctl00_Main_AddPaymentReceipts1_ddlBranch')]")
	public WebElement ddlBranch;
	
	@FindBy(xpath = "//input[@id='ctl00_Main_AddPaymentReceipts1_btnListBills']")
	public WebElement btnListBills;
	
	@FindBy(xpath = "(//input[@type='checkbox'])[2]")
	public WebElement chkListBills;
	
	@FindBy(xpath = "//input[@id='ctl00_Main_AddPaymentReceipts1_ReceivePayment1_txtBankName']")
	public WebElement txtBankName;
	
	@FindBy(xpath = "//input[@id='ctl00_Main_AddPaymentReceipts1_ReceivePayment1_txtChequeDdNo']")
	public WebElement txtChequeDdNo;
	
	@FindBy(xpath = "//select[@id='ctl00_Main_AddPaymentReceipts1_ReceivePayment1_DepositedTo1_ddlDepositedTo']")
	public WebElement ddlDepositedTo;
	
	@FindBy(xpath = "//textarea[@id='ctl00_Main_AddPaymentReceipts1_ReceivePayment1_DepositedTo1_txt_comments']")
	public WebElement txtComments;
	
	@FindBy(xpath = "//input[@id='ctl00_Main_AddPaymentReceipts1_ReceivePayment1_btnPayment']")
	public WebElement btnSubmit;
	
}
