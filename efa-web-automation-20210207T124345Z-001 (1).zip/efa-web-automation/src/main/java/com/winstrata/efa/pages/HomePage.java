package com.winstrata.efa.pages;


import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;


import com.winstrata.efa.pageobjects.HomePageObject;


public class HomePage extends HomePageObject {

	 Actions actions;
	WebDriver driver;
	
	public HomePage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
		this.driver = driver;
		actions = new Actions(driver);
	}

	public void selectProductSetup() throws Exception {

		actions.moveToElement(corporate).build().perform();
		actions.moveToElement(productSetup).doubleClick().build().perform();     
	}
	
	public void selectT2WorkOrder() throws Exception {

		actions.moveToElement(corporate).build().perform();
		actions.moveToElement(t2WorkOrder).doubleClick().build().perform();
		actions.release().perform();
        
	}
	
	public void selectT2ManageJobs() throws Exception {

		actions.moveToElement(corporate).build().perform();
		actions.moveToElement(t2ManageJobs).doubleClick().build().perform();
		actions.release().perform();
        
	}
	
	public void selectT2Departure() throws Exception {

		actions.moveToElement(tripsheet).build().perform();
		Thread.sleep(5000);
//		JavascriptExecutor je = (JavascriptExecutor) driver;
//		je.executeScript("arguments[0].scrollIntoView(true);",t2Departure);
		actions.moveToElement(menuTripSheet).build().perform();
		Thread.sleep(100);
		actions.moveToElement(t2Departure).doubleClick().build().perform();
		actions.release().perform();
		Thread.sleep(5000);
        
	}
	
	public void selectT2Arrival() throws Exception {

		actions.moveToElement(tripsheet).build().perform();
		Thread.sleep(5000);
//		JavascriptExecutor je = (JavascriptExecutor) driver;
//		je.executeScript("arguments[0].scrollIntoView(true);",t2Departure);
		actions.moveToElement(menuTripSheet).build().perform();
		Thread.sleep(100);
		actions.moveToElement(t2Arrival).doubleClick().build().perform();
		actions.release().perform();
		Thread.sleep(5000);
        
	}
	
	public void selectCreditReceipt() throws Exception {

		actions.moveToElement(finance).build().perform();
		Thread.sleep(2000);
//		JavascriptExecutor je = (JavascriptExecutor) driver;
//		je.executeScript("arguments[0].scrollIntoView(true);",t2Departure);
		actions.moveToElement(creditReceipts).doubleClick().build().perform();
	
		actions.release().perform();
		Thread.sleep(5000);
        
	}
	
	public void selectT2BillGeneration() throws Exception {

		actions.moveToElement(finance).build().perform();
		Thread.sleep(2000);
//		JavascriptExecutor je = (JavascriptExecutor) driver;
//		je.executeScript("arguments[0].scrollIntoView(true);",t2Departure);
		actions.moveToElement(t2BillGeneration).doubleClick().build().perform();
	
		actions.release().perform();
		Thread.sleep(5000);
        
	}
}
