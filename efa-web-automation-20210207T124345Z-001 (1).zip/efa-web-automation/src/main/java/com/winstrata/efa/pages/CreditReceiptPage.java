package com.winstrata.efa.pages;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.map.LinkedMap;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.winstrata.efa.pageobjects.CreditReceiptPageObject;
import com.winstrata.efa.utils.Env;

import io.cucumber.datatable.DataTable;

public class CreditReceiptPage extends CreditReceiptPageObject {

	public CreditReceiptPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	public void createCreditReceipt(DataTable table) throws Exception {
		
		 List<Map<String,String>> rows = table.asMaps(String.class, String.class);
		 Thread.sleep(1000);
		waitForElementClickable(btnAddNew).click();
		Thread.sleep(1000);
		
		waitForElementClickable(ddlCustomer).sendKeys(Env.get("customer"));
		Thread.sleep(2000);
		Assert.assertTrue(waitForElementClickable(ddlCustomer).getText().contains( Env.get("customer")));
		waitForElementClickable(btnListBills).click();
		Thread.sleep(2000);
		
		waitForElementClickable(chkListBills).click();
		Thread.sleep(2000);
		waitForElementClickable(txtBankName).sendKeys(rows.get(0).get("BankName"));
		Thread.sleep(2000);
		
		waitForElementClickable(txtChequeDdNo).sendKeys(rows.get(0).get("ChequeNo"));
		Thread.sleep(1000);
		
		Select select = new Select(ddlDepositedTo);
		select.selectByIndex(1);
		Thread.sleep(1000);
		waitForElementClickable(txtComments).sendKeys(rows.get(0).get("Comment"));
		Thread.sleep(1000);
		
		waitForElementClickable(btnSubmit).click();
		Thread.sleep(2000);
	}
}
