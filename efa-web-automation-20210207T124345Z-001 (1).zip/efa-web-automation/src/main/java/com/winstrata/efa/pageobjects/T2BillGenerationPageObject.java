package com.winstrata.efa.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class T2BillGenerationPageObject extends PageObject{

	public T2BillGenerationPageObject(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	@FindBy(xpath = "//input[@value='Generate New Bill']")
	public WebElement btnGenerateNewBill;
	
	@FindBy(xpath = "//input[@id='ctl00_Main_txtCustomer']")
	public WebElement txtCustomer;
	
	@FindBy(xpath = "//select[@id='ctl00_Main_ddlWONo']")
	public WebElement ddlWONo;
	
	@FindBy(xpath = "//select[@id='ctl00_Main_ddlTemplate']")
	public WebElement ddlTemplate;
	
	@FindBy(id = "ctl00_Main_Txtjob")
	public WebElement txtJob;
	
	@FindBy(id = "ctl00_Main_btnHidden")
	public WebElement btnListTrips;
	
	@FindBy(xpath = "/html/body/form/table/tbody/tr[4]/td/div/table/tbody/tr[4]/td/div/div/table/tbody")
	public WebElement cgvBillsTable;
	
	public WebElement selectRadioBtn(int indx) {
		return driver.findElement(By.xpath("(//input[@value='rbtn'])[" + indx + "]"));
	}
	
	@FindBy(xpath = "//input[@value='rbtn']")
	public WebElement rbtnTripSheet;
	
	@FindBy(xpath = "//input[@value='Generate']")
	public WebElement btnGenerate;
	
	@FindBy(xpath = "//input[@value='Confirm & Dispatch']")
	public WebElement btnConfirmDispatch;
	

}
